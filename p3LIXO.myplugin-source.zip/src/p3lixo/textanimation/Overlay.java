package p3lixo.textanimation;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.drawable.Drawable;
import android.os.SystemClock;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Map;
import java.util.Random;
import java.util.WeakHashMap;

/**
 * One drawable per window, attached to the window root's ViewOverlay. It runs a frame loop
 * (postOnAnimation) only while something is animating, and draws ghost letters, particles,
 * the combo counter. It never intercepts touches and is never clipped by child bounds.
 */
final class Overlay extends Drawable implements Runnable {

    interface Item {
        /** @return false when finished and to be removed. */
        boolean step(long now, float dt);

        void draw(Canvas c, long now);
    }

    private static final Map<View, Overlay> ALL = new WeakHashMap<View, Overlay>();

    private final WeakReference<ViewGroup> rootRef;
    private final ArrayList<Item> items = new ArrayList<Item>();
    final Particles particles = new Particles();
    private final int[] la = new int[2], lb = new int[2];
    private boolean running, added;
    private long last;

    private Overlay(ViewGroup root) {
        this.rootRef = new WeakReference<ViewGroup>(root);
    }

    static Overlay of(View any) {
        View r = any.getRootView();
        if (!(r instanceof ViewGroup)) return null;
        Overlay o = ALL.get(r);
        if (o == null) {
            o = new Overlay((ViewGroup) r);
            ALL.put(r, o);
        }
        return o;
    }

    /** Removes every overlay we added (plugin stop). */
    static void releaseAll() {
        for (Overlay o : new ArrayList<Overlay>(ALL.values())) {
            try {
                o.items.clear();
                o.particles.n = 0;
                ViewGroup root = o.rootRef.get();
                if (root != null && o.added) root.getOverlay().remove(o);
                o.added = false;
                o.running = false;
            } catch (Throwable ignored) {
            }
        }
        ALL.clear();
    }

    /** Position of v's top-left corner in root coordinates. */
    void origin(View v, float[] out) {
        ViewGroup r = rootRef.get();
        if (r == null) {
            out[0] = 0;
            out[1] = 0;
            return;
        }
        v.getLocationInWindow(la);
        r.getLocationInWindow(lb);
        out[0] = la[0] - lb[0];
        out[1] = la[1] - lb[1];
    }

    void add(Item it) {
        items.add(it);
        wake();
    }

    void wake() {
        ViewGroup root = rootRef.get();
        if (root == null) return;
        if (!added) {
            root.getOverlay().add(this);
            added = true;
        }
        if (!running) {
            running = true;
            last = SystemClock.uptimeMillis();
            root.postOnAnimation(this);
        }
    }

    @Override
    public void run() {
        ViewGroup root = rootRef.get();
        if (root == null) {
            running = false;
            return;
        }
        long now = SystemClock.uptimeMillis();
        float dt = Math.min(0.05f, (now - last) / 1000f);
        last = now;
        for (int i = items.size() - 1; i >= 0; i--) {
            boolean keep;
            try {
                keep = items.get(i).step(now, dt);
            } catch (Throwable t) {
                keep = false;
            }
            if (!keep) items.remove(i);
        }
        boolean alive = particles.step(dt);
        setBounds(0, 0, root.getWidth(), root.getHeight());
        invalidateSelf();
        if (items.isEmpty() && !alive) {
            running = false;
            root.getOverlay().remove(this);
            added = false;
            return;
        }
        root.postOnAnimation(this);
    }

    @Override
    public void draw(Canvas c) {
        long now = SystemClock.uptimeMillis();
        for (int i = 0, n = items.size(); i < n; i++) {
            try {
                items.get(i).draw(c, now);
            } catch (Throwable ignored) {
            }
        }
        particles.draw(c);
    }

    @Override public void setAlpha(int alpha) {}

    @Override public void setColorFilter(android.graphics.ColorFilter cf) {}

    @Override public int getOpacity() {
        return PixelFormat.TRANSLUCENT;
    }

    // -------------------------------------------------------------- particles

    static final class Particles {
        static final int MAX = 500;
        final float[] x = new float[MAX], y = new float[MAX], vx = new float[MAX],
                vy = new float[MAX], size = new float[MAX], life = new float[MAX],
                age = new float[MAX], grav = new float[MAX];
        final int[] color = new int[MAX];
        final byte[] shape = new byte[MAX];
        int n;
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

        void add(float px, float py, float pvx, float pvy, float sz, float lifeSec,
                 int col, int shp, float g) {
            if (n >= MAX) return;
            int i = n++;
            x[i] = px;
            y[i] = py;
            vx[i] = pvx;
            vy[i] = pvy;
            size[i] = sz;
            life[i] = lifeSec;
            age[i] = 0f;
            color[i] = col;
            shape[i] = (byte) shp;
            grav[i] = g;
        }

        private void move(int from, int to) {
            x[to] = x[from];
            y[to] = y[from];
            vx[to] = vx[from];
            vy[to] = vy[from];
            size[to] = size[from];
            life[to] = life[from];
            age[to] = age[from];
            grav[to] = grav[from];
            color[to] = color[from];
            shape[to] = shape[from];
        }

        boolean step(float dt) {
            int i = 0;
            while (i < n) {
                age[i] += dt;
                if (age[i] >= life[i]) {
                    move(n - 1, i);
                    n--;
                    continue;
                }
                vy[i] += grav[i] * dt;
                x[i] += vx[i] * dt;
                y[i] += vy[i] * dt;
                float drag = 1f - 1.2f * dt;
                vx[i] *= drag;
                i++;
            }
            return n > 0;
        }

        void draw(Canvas c) {
            for (int i = 0; i < n; i++) {
                float k = 1f - age[i] / life[i];
                int base = color[i];
                p.setColor(base);
                p.setAlpha((int) (Color.alpha(base) * k * k));
                float s = size[i] * (0.4f + 0.6f * k);
                switch (shape[i]) {
                    case 1:
                        c.drawRect(x[i] - s / 2, y[i] - s / 2, x[i] + s / 2, y[i] + s / 2, p);
                        break;
                    case 2:
                        p.setStrokeWidth(Math.max(1f, s * 0.45f));
                        c.drawLine(x[i], y[i], x[i] - vx[i] * 0.04f, y[i] - vy[i] * 0.04f, p);
                        break;
                    default:
                        c.drawCircle(x[i], y[i], s / 2, p);
                }
            }
        }
    }

    // ------------------------------------------------------------------ items

    /** A fading, drifting letter left behind by a deletion. */
    static final class Ghost implements Item {
        private final char[] ch = new char[1];
        private final Paint p;
        private final int color;
        private final float x, y, drift, durMs;
        private final long t0;

        Ghost(char c, Paint paint, int color, float x, float y, float drift, float durMs) {
            ch[0] = c;
            this.p = paint;
            this.color = color;
            this.x = x;
            this.y = y;
            this.drift = drift;
            this.durMs = durMs;
            this.t0 = SystemClock.uptimeMillis();
        }

        @Override public boolean step(long now, float dt) {
            return now - t0 < durMs;
        }

        @Override public void draw(Canvas c, long now) {
            float k = Ease.clamp01((now - t0) / durMs);
            p.setColor(color);
            p.setAlpha((int) (Color.alpha(color) * (1f - k) * (1f - k)));
            c.drawText(ch, 0, 1, x, y + drift * k, p);
        }
    }

    /** Shakes a view for a short time and puts its translation back. */
    static final class Shake implements Item {
        private final WeakReference<View> ref;
        private final float baseX, baseY;
        private final Random rnd = new Random();
        private long t0;
        private float amp;
        private final long durMs;

        Shake(View v, float amp, long durMs) {
            this.ref = new WeakReference<View>(v);
            this.baseX = v.getTranslationX();
            this.baseY = v.getTranslationY();
            this.amp = amp;
            this.durMs = durMs;
            this.t0 = SystemClock.uptimeMillis();
        }

        void refresh(float newAmp) {
            t0 = SystemClock.uptimeMillis();
            amp = Math.max(amp * 0.6f, newAmp);
        }

        @Override public boolean step(long now, float dt) {
            View v = ref.get();
            if (v == null) return false;
            long el = now - t0;
            if (el >= durMs) {
                v.setTranslationX(baseX);
                v.setTranslationY(baseY);
                return false;
            }
            float k = 1f - el / (float) durMs;
            v.setTranslationX(baseX + (rnd.nextFloat() * 2f - 1f) * amp * k);
            v.setTranslationY(baseY + (rnd.nextFloat() * 2f - 1f) * amp * 0.6f * k);
            return true;
        }

        @Override public void draw(Canvas c, long now) {}

        void restoreNow() {
            View v = ref.get();
            if (v != null) {
                v.setTranslationX(baseX);
                v.setTranslationY(baseY);
            }
        }
    }

    interface ComboSource {
        int combo();

        long lastType();

        int windowMs();

        int accent();

        void counterDone();
    }

    /** "x12" label that pops over the top-right corner of the field. */
    static final class Counter implements Item {
        private final WeakReference<EditText> tvRef;
        private final Overlay ov;
        private final ComboSource src;
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final float[] org = new float[2];

        Counter(EditText tv, Overlay ov, ComboSource src) {
            this.tvRef = new WeakReference<EditText>(tv);
            this.ov = ov;
            this.src = src;
            p.setTextAlign(Paint.Align.RIGHT);
            p.setFakeBoldText(true);
        }

        @Override public boolean step(long now, float dt) {
            EditText tv = tvRef.get();
            boolean keep = tv != null && now - src.lastType() < src.windowMs() + 500L;
            if (!keep) src.counterDone();
            return keep;
        }

        @Override public void draw(Canvas c, long now) {
            EditText tv = tvRef.get();
            if (tv == null || src.combo() < 3 || !tv.isShown()) return;
            float d = tv.getResources().getDisplayMetrics().density;
            long since = now - src.lastType();
            float fade = 1f - Ease.clamp01((since - src.windowMs()) / 500f);
            float pop = 1f + 0.45f * Math.max(0f, 1f - since / 160f);
            ov.origin(tv, org);
            float x = org[0] + tv.getWidth() - 8f * d;
            float y = org[1] - 6f * d;
            p.setTextSize(18f * d * pop);
            p.setColor(src.accent());
            p.setAlpha((int) (255 * fade));
            c.drawText("x" + src.combo(), x, y, p);
        }
    }
}
