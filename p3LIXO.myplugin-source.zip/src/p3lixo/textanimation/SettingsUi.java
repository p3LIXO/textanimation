package p3lixo.textanimation;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.graphics.PorterDuff;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.text.InputType;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;

/** The settings window: preview field on top, presets, then every option from Cfg.LIST. */
final class SettingsUi {

    private static final int BG = 0xFF1E1F22;
    private static final int CARD = 0xFF2B2D31;
    private static final int TXT = 0xFFEDEDED;
    private static final int MUTED = 0xFF9A9AA0;
    private static final int ACC = 0xFFFFFFFF;

    private SettingsUi() {}

    private static int dp(Context c, float v) {
        return Math.round(v * c.getResources().getDisplayMetrics().density);
    }

    private static GradientDrawable round(int color, float radiusDp, Context c) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(c, radiusDp));
        return g;
    }

    static void show(final Activity act, final TextAnimation host) {
        final Cfg cfg = host.cfg;
        final SharedPreferences prefs = host.prefs();

        LinearLayout root = new LinearLayout(act);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackground(round(BG, 24, act));
        root.setPadding(dp(act, 16), dp(act, 14), dp(act, 16), dp(act, 8));

        TextView title = new TextView(act);
        title.setText("Text Animation");
        title.setTextColor(TXT);
        title.setTextSize(20);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        root.addView(title);

        // ---- live preview field
        final EditText preview = new EditText(act);
        preview.setHint(Cfg.tr("Печатайте здесь: предпросмотр", "Type here: preview"));
        preview.setHintTextColor(MUTED);
        preview.setTextColor(TXT);
        preview.setTextSize(18);
        preview.setMaxLines(3);
        preview.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        preview.setBackground(round(CARD, 14, act));
        preview.setPadding(dp(act, 14), dp(act, 12), dp(act, 14), dp(act, 12));
        LinearLayout.LayoutParams plp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        plp.topMargin = dp(act, 10);
        root.addView(preview, plp);

        // ---- presets
        LinearLayout presets = new LinearLayout(act);
        presets.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams prlp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        prlp.topMargin = dp(act, 8);
        root.addView(presets, prlp);

        // ---- scrolling list
        final LinearLayout list = new LinearLayout(act);
        list.setOrientation(LinearLayout.VERTICAL);
        ScrollView sv = new ScrollView(act);
        sv.addView(list);
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f);
        slp.topMargin = dp(act, 6);
        root.addView(sv, slp);

        final Runnable[] fill = new Runnable[1];
        fill[0] = new Runnable() {
            @Override public void run() {
                list.removeAllViews();
                for (int i = 0; i < Cfg.LIST.size(); i++) {
                    Cfg.Opt o = Cfg.LIST.get(i);
                    switch (o.type) {
                        case Cfg.T_SECTION:
                            list.addView(sectionRow(act, o.label));
                            break;
                        case Cfg.T_BOOL:
                            list.addView(switchRow(act, cfg, prefs, host, i));
                            break;
                        case Cfg.T_INT:
                            list.addView(seekRow(act, cfg, prefs, host, i));
                            break;
                        default:
                            list.addView(choiceRow(act, cfg, prefs, host, i));
                    }
                }
            }
        };
        fill[0].run();

        addChip(act, presets, Cfg.tr("Мягкий", "Soft"), new Runnable() {
            @Override public void run() {
                cfg.applyPreset(prefs, Cfg.PRESET_SOFT);
                host.onCfgChanged();
                fill[0].run();
            }
        });
        addChip(act, presets, Cfg.tr("Неон", "Neon"), new Runnable() {
            @Override public void run() {
                cfg.applyPreset(prefs, Cfg.PRESET_NEON);
                host.onCfgChanged();
                fill[0].run();
            }
        });
        addChip(act, presets, Cfg.tr("Хаос", "Chaos"), new Runnable() {
            @Override public void run() {
                cfg.applyPreset(prefs, Cfg.PRESET_CHAOS);
                host.onCfgChanged();
                fill[0].run();
            }
        });

        // ---- footer
        LinearLayout footer = new LinearLayout(act);
        footer.setOrientation(LinearLayout.HORIZONTAL);
        footer.setGravity(Gravity.END);
        root.addView(footer, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        final AlertDialog dialog = new AlertDialog.Builder(act).setView(root).create();

        TextView reset = button(act, Cfg.tr("Сбросить", "Reset"), MUTED);
        reset.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                cfg.reset(prefs);
                host.onCfgChanged();
                fill[0].run();
            }
        });
        footer.addView(reset);
        TextView close = button(act, Cfg.tr("Закрыть", "Close"), ACC);
        close.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                dialog.dismiss();
            }
        });
        footer.addView(close);

        dialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override public void onDismiss(DialogInterface d) {
                host.detachFx(preview);
            }
        });
        dialog.show();
        host.attachFx(preview);

        Window w = dialog.getWindow();
        if (w != null) {
            w.setBackgroundDrawable(new ColorDrawable(0));
            DisplayMetrics dm = act.getResources().getDisplayMetrics();
            w.setLayout((int) (dm.widthPixels * 0.94f), (int) (dm.heightPixels * 0.80f));
            w.setGravity(Gravity.TOP | Gravity.CENTER_HORIZONTAL);
            WindowManager.LayoutParams lp = w.getAttributes();
            lp.y = dp(act, 28);
            lp.dimAmount = 0.5f;
            w.setAttributes(lp);
            w.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING);
        }
    }

    // ------------------------------------------------------------------ rows

    private static TextView button(Context c, String text, int color) {
        TextView b = new TextView(c);
        b.setText(text);
        b.setTextColor(color);
        b.setTextSize(15);
        b.setTypeface(null, android.graphics.Typeface.BOLD);
        b.setPadding(dp(c, 14), dp(c, 12), dp(c, 14), dp(c, 12));
        return b;
    }

    private static void addChip(Context c, LinearLayout parent, String text, final Runnable action) {
        TextView t = new TextView(c);
        t.setText(text);
        t.setTextColor(TXT);
        t.setTextSize(14);
        t.setGravity(Gravity.CENTER);
        t.setBackground(round(CARD, 18, c));
        t.setPadding(dp(c, 14), dp(c, 8), dp(c, 14), dp(c, 8));
        t.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                action.run();
            }
        });
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        lp.rightMargin = dp(c, 8);
        parent.addView(t, lp);
    }

    private static View sectionRow(Context c, String label) {
        TextView t = new TextView(c);
        t.setText(label.toLowerCase());
        t.setTextColor(MUTED);
        t.setTextSize(12);
        t.setTypeface(null, android.graphics.Typeface.BOLD);
        t.setPadding(dp(c, 4), dp(c, 18), dp(c, 4), dp(c, 4));
        return t;
    }

    private static TextView label(Context c, String text) {
        TextView t = new TextView(c);
        t.setText(text);
        t.setTextColor(TXT);
        t.setTextSize(15);
        return t;
    }

    private static View switchRow(final Context c, final Cfg cfg, final SharedPreferences p,
                                  final TextAnimation host, final int idx) {
        LinearLayout row = new LinearLayout(c);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(c, 4), dp(c, 10), dp(c, 4), dp(c, 10));

        TextView lab = label(c, Cfg.LIST.get(idx).label);
        row.addView(lab, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        final Switch sw = new Switch(c);
        sw.setChecked(cfg.on(idx));
        sw.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override public void onCheckedChanged(CompoundButton b, boolean on) {
                cfg.set(p, idx, on ? 1 : 0);
                host.onCfgChanged();
            }
        });
        row.addView(sw);
        row.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                sw.toggle();
            }
        });
        return row;
    }

    private static View seekRow(final Context c, final Cfg cfg, final SharedPreferences p,
                                final TextAnimation host, final int idx) {
        final Cfg.Opt o = Cfg.LIST.get(idx);
        LinearLayout col = new LinearLayout(c);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(c, 4), dp(c, 10), dp(c, 4), dp(c, 4));

        LinearLayout top = new LinearLayout(c);
        top.setOrientation(LinearLayout.HORIZONTAL);
        TextView lab = label(c, o.label);
        top.addView(lab, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        final TextView val = new TextView(c);
        val.setTextColor(MUTED);
        val.setTextSize(14);
        top.addView(val);
        col.addView(top);

        final String unit = o.unit == null ? "" : o.unit;
        val.setText(cfg.get(idx) + unit);

        final SeekBar sb = new SeekBar(c);
        sb.setMax((o.max - o.min) / o.step);
        sb.setProgress((cfg.get(idx) - o.min) / o.step);
        sb.getProgressDrawable().setColorFilter(ACC, PorterDuff.Mode.SRC_IN);
        sb.getThumb().setColorFilter(ACC, PorterDuff.Mode.SRC_IN);
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int progress, boolean fromUser) {
                int value = o.min + progress * o.step;
                val.setText(value + unit);
                if (fromUser) cfg.v[idx] = value; // live preview, saved on release
            }

            @Override public void onStartTrackingTouch(SeekBar s) {}

            @Override public void onStopTrackingTouch(SeekBar s) {
                cfg.set(p, idx, o.min + s.getProgress() * o.step);
                host.onCfgChanged();
            }
        });
        col.addView(sb);
        return col;
    }

    private static View choiceRow(final Context c, final Cfg cfg, final SharedPreferences p,
                                  final TextAnimation host, final int idx) {
        final Cfg.Opt o = Cfg.LIST.get(idx);
        LinearLayout row = new LinearLayout(c);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(c, 4), dp(c, 12), dp(c, 4), dp(c, 12));

        row.addView(label(c, o.label),
                new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        final TextView val = new TextView(c);
        val.setTextColor(MUTED);
        val.setTextSize(14);
        val.setText(o.choices[cfg.get(idx)]);
        row.addView(val);

        row.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                new AlertDialog.Builder(c)
                        .setTitle(o.label)
                        .setItems(o.choices, new DialogInterface.OnClickListener() {
                            @Override public void onClick(DialogInterface d, int which) {
                                cfg.set(p, idx, which);
                                val.setText(o.choices[which]);
                                host.onCfgChanged();
                            }
                        }).show();
            }
        });
        return row;
    }
}
