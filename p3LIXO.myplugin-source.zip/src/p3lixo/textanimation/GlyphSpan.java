package p3lixo.textanimation;

import android.text.TextPaint;
import android.text.style.CharacterStyle;
import android.text.style.UpdateAppearance;

/**
 * Hides one real glyph while its animated "ghost" is drawn on the overlay.
 * It only changes colour (UpdateAppearance), never metrics, so layout is untouched.
 * The span is removed when the animation ends, which makes the real glyph visible again.
 */
final class GlyphSpan extends CharacterStyle implements UpdateAppearance {
    @Override
    public void updateDrawState(TextPaint tp) {
        tp.setAlpha(0);
    }
}
