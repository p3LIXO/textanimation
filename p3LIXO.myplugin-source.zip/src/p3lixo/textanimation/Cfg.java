package p3lixo.textanimation;

import android.content.SharedPreferences;
import java.util.ArrayList;
import java.util.Locale;

/** All plugin options: one table drives defaults, storage and the settings screen. */
final class Cfg {

    static final int T_SECTION = 0, T_BOOL = 1, T_INT = 2, T_CHOICE = 3;

    static final class Opt {
        final int type;
        final String key, label, unit;
        final int def, min, max, step;
        final String[] choices;

        Opt(int type, String key, String label, int def, int min, int max, int step,
            String unit, String[] choices) {
            this.type = type;
            this.key = key;
            this.label = label;
            this.def = def;
            this.min = min;
            this.max = max;
            this.step = step;
            this.unit = unit;
            this.choices = choices;
        }
    }

    static boolean isRu() {
        String l = Locale.getDefault().getLanguage();
        return "ru".equals(l) || "uk".equals(l) || "be".equals(l);
    }

    static String tr(String ru, String en) {
        return isRu() ? ru : en;
    }

    // ------------------------------------------------------------------ table

    static final ArrayList<Opt> LIST = new ArrayList<Opt>();

    private static int add(Opt o) {
        LIST.add(o);
        return LIST.size() - 1;
    }

    private static int sec(String ru, String en) {
        return add(new Opt(T_SECTION, null, tr(ru, en), 0, 0, 0, 0, null, null));
    }

    private static int bool(String key, String ru, String en, boolean def) {
        return add(new Opt(T_BOOL, key, tr(ru, en), def ? 1 : 0, 0, 1, 1, null, null));
    }

    private static int num(String key, String ru, String en, int def, int min, int max,
                           int step, String unit) {
        return add(new Opt(T_INT, key, tr(ru, en), def, min, max, step, unit, null));
    }

    private static int choice(String key, String ru, String en, int def,
                              String[] chRu, String[] chEn) {
        String[] c = isRu() ? chRu : chEn;
        return add(new Opt(T_CHOICE, key, tr(ru, en), def, 0, c.length - 1, 1, null, c));
    }

    static final String MS = tr(" мс", " ms");

    static final int S_GEN = sec("Общее", "General");
    static final int TYPING = bool("typing", "Анимация при наборе (поля ввода)",
            "Animate typing (input fields)", true);
    static final int OTHER = bool("other", "Анимировать остальной текст при смене",
            "Animate other text when it changes", true);

    static final int S_BEHAVIOR = sec("Поведение текста", "Text behavior");
    static final int PER_CHAR = bool("per_char", "Анимировать каждый символ",
            "Animate every character", true);
    static final int IGN_SPACES = bool("ign_spaces", "Игнорировать пробелы",
            "Ignore spaces", true);
    static final int DURATION = num("duration", "Длительность появления",
            "Appear duration", 290, 60, 1200, 10, MS);
    static final int EASING = choice("easing", "Характер появления", "Appear style", 0,
            new String[]{"Мягкий", "Линейный", "Резкий", "Пружина"},
            new String[]{"Soft", "Linear", "Sharp", "Spring"});

    static final int S_BLUR = sec("Мягкое появление", "Soft appear");
    static final int BLUR = bool("blur", "Появляться из размытия", "Appear from blur", true);
    static final int BLUR_DUR = num("blur_dur", "Длительность размытия", "Blur duration",
            285, 60, 1200, 5, MS);
    static final int BLUR_STRENGTH = num("blur_strength", "Сила размытия", "Blur strength",
            10, 0, 30, 1, "");
    static final int BLUR_PAUSE = num("blur_pause", "Пауза перед чётким текстом",
            "Pause before sharp text", 20, 0, 80, 5, "%");

    static final int S_MOTION = sec("Движение символов", "Character motion");
    static final int SLIDE = bool("slide", "Лёгкий въезд сверху", "Slide in from above", true);
    static final int SLIDE_DIST = num("slide_dist", "Дистанция въезда", "Slide distance",
            12, 0, 48, 1, " dp");
    static final int SCALE = bool("scale", "Добавить масштаб", "Add scale", true);
    static final int SCALE_START = num("scale_start", "Стартовый масштаб", "Start scale",
            60, 0, 100, 5, "%");
    static final int ROTATE = bool("rotate", "Чуть поворачивать букву", "Tilt the letter", false);
    static final int ANGLE = num("angle", "Угол поворота", "Tilt angle", -12, -45, 45, 1, "°");
    static final int HIGHLIGHT = bool("highlight", "Подсвечивать новые", "Highlight new letters",
            true);
    static final int HL_STRENGTH = num("hl_strength", "Яркость подсветки", "Highlight strength",
            70, 0, 100, 5, "%");
    static final int ACCENT = choice("accent", "Акцентный цвет", "Accent colour", 1,
            new String[]{"Розовый", "Голубой", "Белый", "Жёлтый", "Зелёный"},
            new String[]{"Pink", "Cyan", "White", "Yellow", "Green"});

    static final int S_PASTE = sec("Вставка", "Paste");
    static final int WAVE = bool("wave", "Вставка проявляется волной", "Paste appears as a wave",
            true);
    static final int WAVE_STEP = num("wave_step", "Шаг волны", "Wave step", 25, 0, 80, 5, MS);

    static final int S_DELETE = sec("Удаление текста", "Deleting text");
    static final int FADE_DEL = bool("fade_del", "Плавное исчезновение", "Smooth fade out", true);
    static final int CRUMBLE = bool("crumble", "Рассыпать буквы при удалении",
            "Crumble letters on delete", true);
    static final int SHAPE = choice("shape", "Во что рассыпаются буквы", "Crumble into", 0,
            new String[]{"Точки", "Квадраты", "Искры", "Вперемешку"},
            new String[]{"Dots", "Squares", "Sparks", "Mixed"});
    static final int PCS = num("pcs", "Частиц с одной буквы", "Particles per letter",
            6, 1, 16, 1, "");
    static final int FLY_SPEED = num("fly_speed", "Скорость разлёта", "Fly speed", 50, 0, 100, 5, "");
    static final int SPREAD = num("spread", "Ширина разлёта", "Spread", 50, 0, 100, 5, "");
    static final int PSIZE = num("psize", "Размер частиц", "Particle size", 50, 10, 100, 5, "");
    static final int GRAVITY = bool("gravity", "Частицы падают", "Particles fall", true);
    static final int GRAV_STR = num("grav_str", "Сила падения", "Gravity", 100, 0, 200, 10, "%");

    static final int S_LIVE = sec("Живая печать", "Live typing");
    static final int COMBO = bool("combo", "Комбо за скорость печати", "Typing speed combo", false);
    static final int COMBO_WIN = num("combo_win", "Окно комбо", "Combo window", 700, 300, 2000,
            50, MS);
    static final int SHAKE = num("shake", "Сила тряски", "Shake strength", 3, 0, 10, 1, " dp");
    static final int SPARKS = bool("sparks", "Искры на быстрой печати", "Sparks on fast typing",
            true);
    static final int COUNTER = bool("counter", "Показывать счётчик комбо", "Show combo counter",
            true);

    static final int S_REACT = sec("Реакции", "Reactions");
    static final int REACT = bool("react", "Реагировать на ! и ?", "React to ! and ?", true);
    static final int HAPTIC = bool("haptic", "Виброотклик", "Haptic feedback", false);

    static final int S_CURSOR = sec("Курсор", "Cursor");
    static final int CURSOR = bool("cursor", "Оформить курсор (Android 10+)",
            "Style the cursor (Android 10+)", false);
    static final int CURSOR_W = num("cursor_w", "Толщина курсора", "Cursor width", 3, 1, 8, 1, " dp");

    static final int S_DIAG = sec("Диагностика", "Diagnostics");
    static final int VERBOSE = bool("verbose", "Писать подробные логи", "Verbose logs", false);

    static final int[] ACCENTS = {0xFFFE2C55, 0xFF25F4EE, 0xFFFFFFFF, 0xFFFFD54F, 0xFF69F0AE};

    // ----------------------------------------------------------------- values

    final int[] v = new int[LIST.size()];

    Cfg() {
        for (int i = 0; i < v.length; i++) v[i] = LIST.get(i).def;
    }

    boolean on(int idx) {
        return v[idx] != 0;
    }

    int get(int idx) {
        return v[idx];
    }

    int accent() {
        int a = v[ACCENT];
        return ACCENTS[(a >= 0 && a < ACCENTS.length) ? a : 1];
    }

    void load(SharedPreferences p) {
        for (int i = 0; i < v.length; i++) {
            Opt o = LIST.get(i);
            if (o.type == T_SECTION) continue;
            int x;
            try {
                x = p.getInt(o.key, o.def);
            } catch (Throwable t) {
                x = o.def;
            }
            v[i] = Math.max(o.min, Math.min(o.max, x));
        }
    }

    void set(SharedPreferences p, int idx, int value) {
        Opt o = LIST.get(idx);
        value = Math.max(o.min, Math.min(o.max, value));
        v[idx] = value;
        if (p != null && o.key != null) p.edit().putInt(o.key, value).apply();
    }

    void reset(SharedPreferences p) {
        for (int i = 0; i < v.length; i++) {
            if (LIST.get(i).type != T_SECTION) set(p, i, LIST.get(i).def);
        }
    }

    // ---------------------------------------------------------------- presets

    /** Pairs of (option, value). */
    static final int[] PRESET_SOFT = {
            BLUR, 1, BLUR_STRENGTH, 8, SLIDE, 1, SLIDE_DIST, 8, SCALE, 1, SCALE_START, 80,
            ROTATE, 0, HIGHLIGHT, 0, EASING, 0, DURATION, 260, CRUMBLE, 1, PCS, 4,
            COMBO, 0, REACT, 0};
    static final int[] PRESET_NEON = {
            BLUR, 1, BLUR_STRENGTH, 16, SLIDE, 1, SLIDE_DIST, 16, SCALE, 1, SCALE_START, 40,
            ROTATE, 1, ANGLE, -14, HIGHLIGHT, 1, HL_STRENGTH, 100, ACCENT, 0, EASING, 3,
            DURATION, 360, CURSOR, 1, COMBO, 0, REACT, 1};
    static final int[] PRESET_CHAOS = {
            BLUR, 1, BLUR_STRENGTH, 12, SLIDE, 1, SLIDE_DIST, 20, SCALE, 1, SCALE_START, 20,
            ROTATE, 1, ANGLE, -25, HIGHLIGHT, 1, HL_STRENGTH, 90, ACCENT, 1, EASING, 3,
            DURATION, 380, CRUMBLE, 1, PCS, 12, SPREAD, 90, FLY_SPEED, 80, GRAVITY, 1,
            COMBO, 1, SHAKE, 5, SPARKS, 1, COUNTER, 1, REACT, 1};

    void applyPreset(SharedPreferences p, int[] pairs) {
        for (int i = 0; i + 1 < pairs.length; i += 2) set(p, pairs[i], pairs[i + 1]);
    }
}
