package p3lixo.textanimation;

import android.app.Activity;
import android.content.Context;
import android.os.SystemClock;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.EditText;
import android.widget.TextView;
import cat.narezany.margyt.plugin.MargyPlugin;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Map;
import java.util.WeakHashMap;

/**
 * Text Animation: animates a TextView whenever its text changes.
 *
 * Styles (prefs key "style", default 0):
 *   0 = fade + slide up, 1 = typewriter (short texts), 2 = pop (scale + fade)
 */
public final class TextAnimation extends MargyPlugin {

    private static final int STYLE_FADE_SLIDE = 0;
    private static final int STYLE_TYPEWRITER = 1;
    private static final int STYLE_POP = 2;

    private static final long SCAN_INTERVAL_MS = 500;
    private static final int TYPEWRITER_MAX_CHARS = 40;
    private static final long TYPEWRITER_STEP_MS = 25;
    private static final long FADE_MS = 220;

    // Weak keys, and nothing stored in values holds a strong ref back to the key.
    private final Map<TextView, TextWatcher> watchers = new WeakHashMap<TextView, TextWatcher>();
    private final Map<View, ViewTreeObserver.OnGlobalLayoutListener> roots =
            new WeakHashMap<View, ViewTreeObserver.OnGlobalLayoutListener>();
    private final Map<TextView, String> typing = new WeakHashMap<TextView, String>();

    private boolean enabled;
    private int style;
    private boolean errorLogged;

    @Override
    public void onStart(Context context) {
        enabled = true;
        style = readStyle();
        margyt().log("TextAnimation: started, style=" + style);
    }

    @Override
    public void onActivityResumed(Activity activity) {
        if (!enabled) return;
        try {
            View decor = activity.getWindow().getDecorView();
            if (!roots.containsKey(decor)) {
                RootListener l = new RootListener(this, decor);
                decor.getViewTreeObserver().addOnGlobalLayoutListener(l);
                roots.put(decor, l);
            }
            style = readStyle();
            scan(decor);
        } catch (Throwable t) {
            fail(t);
        }
    }

    @Override
    public void onStop() {
        enabled = false;
        try {
            for (View v : new ArrayList<View>(roots.keySet())) {
                ViewTreeObserver.OnGlobalLayoutListener l = roots.get(v);
                if (v != null && l != null) {
                    v.getViewTreeObserver().removeOnGlobalLayoutListener(l);
                }
            }
            for (TextView tv : new ArrayList<TextView>(watchers.keySet())) {
                TextWatcher w = watchers.get(tv);
                if (tv != null && w != null) {
                    tv.removeTextChangedListener(w);
                    tv.animate().cancel();
                    tv.setAlpha(1f);
                    tv.setScaleX(1f);
                    tv.setScaleY(1f);
                    tv.setTranslationY(0f);
                }
            }
        } catch (Throwable t) {
            fail(t);
        }
        roots.clear();
        watchers.clear();
        margyt().log("TextAnimation: stopped");
    }

    // ---------------------------------------------------------------- scanning

    void scan(View v) {
        if (v instanceof TextView && !(v instanceof EditText)) {
            watch((TextView) v);
        }
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0, n = g.getChildCount(); i < n; i++) {
                scan(g.getChildAt(i));
            }
        }
    }

    private void watch(TextView tv) {
        if (watchers.containsKey(tv)) return;
        TextWatcher w = new Watcher(this, tv);
        tv.addTextChangedListener(w);
        watchers.put(tv, w);
    }

    // --------------------------------------------------------------- animation

    void onTextChanged(TextView tv) {
        if (!enabled || typing.containsKey(tv) || !tv.isShown()) return;
        CharSequence text = tv.getText();
        if (text == null || text.length() == 0) return;

        switch (style) {
            case STYLE_TYPEWRITER:
                if (text.length() <= TYPEWRITER_MAX_CHARS) {
                    typewriter(tv, text);
                } else {
                    fadeSlide(tv);
                }
                break;
            case STYLE_POP:
                pop(tv);
                break;
            default:
                fadeSlide(tv);
        }
    }

    private void fadeSlide(TextView tv) {
        float dy = 6f * tv.getResources().getDisplayMetrics().density;
        tv.animate().cancel();
        tv.setAlpha(0f);
        tv.setTranslationY(dy);
        tv.animate().alpha(1f).translationY(0f).setDuration(FADE_MS).start();
    }

    private void pop(TextView tv) {
        tv.animate().cancel();
        tv.setAlpha(0f);
        tv.setScaleX(0.85f);
        tv.setScaleY(0.85f);
        tv.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(FADE_MS).start();
    }

    private void typewriter(final TextView tv, final CharSequence original) {
        final String full = original.toString();
        typing.put(tv, "");
        tv.post(new Runnable() {
            private int shown = 0;
            private String last = null;

            @Override
            public void run() {
                try {
                    boolean externalChange = last != null && !last.equals(tv.getText().toString());
                    if (externalChange) {
                        // Somebody else set new text mid-animation: leave it alone.
                        typing.remove(tv);
                        return;
                    }
                    if (!enabled || !tv.isAttachedToWindow() || shown >= full.length()) {
                        tv.setText(original); // restore spans / styling
                        typing.remove(tv);
                        return;
                    }
                    shown++;
                    last = full.substring(0, shown);
                    tv.setText(last);
                    tv.postDelayed(this, TYPEWRITER_STEP_MS);
                } catch (Throwable t) {
                    typing.remove(tv);
                    fail(t);
                }
            }
        });
    }

    // ----------------------------------------------------------------- helpers

    private int readStyle() {
        try {
            int s = margyt().prefs().getInt("style", STYLE_FADE_SLIDE);
            return (s >= STYLE_FADE_SLIDE && s <= STYLE_POP) ? s : STYLE_FADE_SLIDE;
        } catch (Throwable t) {
            return STYLE_FADE_SLIDE;
        }
    }

    void fail(Throwable t) {
        if (!errorLogged) {
            errorLogged = true;
            margyt().log("TextAnimation error: " + t);
        }
    }

    // ------------------------------------------------------- listener classes

    private static final class Watcher implements TextWatcher {
        private final TextAnimation plugin;
        private final WeakReference<TextView> ref;

        Watcher(TextAnimation plugin, TextView tv) {
            this.plugin = plugin;
            this.ref = new WeakReference<TextView>(tv);
        }

        @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
        @Override public void onTextChanged(CharSequence s, int a, int b, int c) {}

        @Override
        public void afterTextChanged(Editable s) {
            TextView tv = ref.get();
            if (tv == null) return;
            try {
                plugin.onTextChanged(tv);
            } catch (Throwable t) {
                plugin.fail(t);
            }
        }
    }

    private static final class RootListener implements ViewTreeObserver.OnGlobalLayoutListener {
        private final TextAnimation plugin;
        private final WeakReference<View> ref;
        private long lastScan;

        RootListener(TextAnimation plugin, View root) {
            this.plugin = plugin;
            this.ref = new WeakReference<View>(root);
        }

        @Override
        public void onGlobalLayout() {
            View root = ref.get();
            if (root == null || !plugin.enabled) return;
            long now = SystemClock.uptimeMillis();
            if (now - lastScan < SCAN_INTERVAL_MS) return; // keep the layout path cheap
            lastScan = now;
            try {
                plugin.scan(root);
            } catch (Throwable t) {
                plugin.fail(t);
            }
        }
    }
}
