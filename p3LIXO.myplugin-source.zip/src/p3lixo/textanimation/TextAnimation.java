package p3lixo.textanimation;

import android.app.Activity;
import android.content.Context;
import android.os.SystemClock;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.EditText;
import android.widget.TextView;
import cat.narezany.margyt.plugin.MargyPlugin;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Map;
import java.util.WeakHashMap;

/**
 * Text Animation: animates a TextView whenever its text changes.
 *
 * Safe approach: nothing is attached to TikTok's TextViews (no TextWatcher, which would turn
 * their text into Editable). The plugin only polls the view tree (throttled) and compares text.
 *
 * Styles (prefs key "style", default 0):
 *   0 = fade + slide up, 1 = typewriter (short texts), 2 = pop (scale + fade)
 */
public final class TextAnimation extends MargyPlugin {

    private static final int STYLE_FADE_SLIDE = 0;
    private static final int STYLE_TYPEWRITER = 1;
    private static final int STYLE_POP = 2;

    private static final long SCAN_INTERVAL_MS = 200;
    private static final int MAX_ANIMATIONS_PER_SCAN = 8;
    private static final int MAX_DEPTH = 60;
    private static final int MAX_SNAPSHOT_CHARS = 200;
    private static final int TYPEWRITER_MAX_CHARS = 40;
    private static final long TYPEWRITER_STEP_MS = 25;
    private static final long FADE_MS = 220;
    private static final int MAX_ERRORS = 5;

    private final Map<TextView, String> seen = new WeakHashMap<TextView, String>();
    private final Map<TextView, Boolean> typing = new WeakHashMap<TextView, Boolean>();
    private final Map<View, RootListener> roots = new WeakHashMap<View, RootListener>();

    private boolean enabled;
    private int style;
    private int errors;
    private int budget;

    @Override
    public void onStart(Context context) {
        enabled = true;
        style = readStyle();
        margyt().log("TextAnimation: started, style=" + style);
    }

    @Override
    public void onActivityResumed(Activity activity) {
        if (!enabled) return;
        try {
            View decor = activity.getWindow().getDecorView();
            if (!roots.containsKey(decor)) {
                ViewTreeObserver vto = decor.getViewTreeObserver();
                if (vto != null && vto.isAlive()) {
                    RootListener l = new RootListener(this, decor);
                    vto.addOnPreDrawListener(l);
                    roots.put(decor, l);
                }
            }
            style = readStyle();
        } catch (Throwable t) {
            fail(t);
        }
    }

    @Override
    public void onStop() {
        enabled = false;
        try {
            for (View v : new ArrayList<View>(roots.keySet())) {
                RootListener l = roots.get(v);
                if (v != null && l != null) {
                    ViewTreeObserver vto = v.getViewTreeObserver();
                    if (vto != null && vto.isAlive()) vto.removeOnPreDrawListener(l);
                }
            }
            for (TextView tv : new ArrayList<TextView>(seen.keySet())) {
                if (tv == null) continue;
                tv.animate().cancel();
                tv.setAlpha(1f);
                tv.setScaleX(1f);
                tv.setScaleY(1f);
                tv.setTranslationY(0f);
            }
        } catch (Throwable t) {
            // ignore on shutdown
        }
        roots.clear();
        seen.clear();
        margyt().log("TextAnimation: stopped");
    }

    // ---------------------------------------------------------------- scanning

    void scan(View root) {
        budget = MAX_ANIMATIONS_PER_SCAN;
        visit(root, 0);
    }

    private void visit(View v, int depth) {
        if (v == null || depth > MAX_DEPTH || v.getVisibility() != View.VISIBLE) return;
        if (v instanceof TextView && !(v instanceof EditText)) {
            check((TextView) v);
        }
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0, n = g.getChildCount(); i < n; i++) {
                visit(g.getChildAt(i), depth + 1);
            }
        }
    }

    private static String snapshot(CharSequence t) {
        if (t == null) return "";
        int len = t.length();
        if (len > MAX_SNAPSHOT_CHARS) return "\u0000" + len; // long text: compare by length only
        return t.toString();
    }

    private void check(TextView tv) {
        CharSequence text = tv.getText();
        String key = snapshot(text);
        String prev = seen.get(tv);
        if (prev == null) {          // first time we see this view: remember, don't animate
            seen.put(tv, key);
            return;
        }
        if (prev.equals(key)) return;
        seen.put(tv, key);
        if (typing.containsKey(tv) || key.length() == 0 || budget <= 0) return;
        if (!tv.isShown()) return;
        budget--;
        animate(tv, text);
    }

    // --------------------------------------------------------------- animation

    private void animate(TextView tv, CharSequence text) {
        switch (style) {
            case STYLE_TYPEWRITER:
                if (text.length() <= TYPEWRITER_MAX_CHARS) {
                    typewriter(tv, text);
                } else {
                    fadeSlide(tv);
                }
                break;
            case STYLE_POP:
                pop(tv);
                break;
            default:
                fadeSlide(tv);
        }
    }

    private void fadeSlide(TextView tv) {
        float dy = 6f * tv.getResources().getDisplayMetrics().density;
        tv.animate().cancel();
        tv.setAlpha(0f);
        tv.setTranslationY(dy);
        tv.animate().alpha(1f).translationY(0f).setDuration(FADE_MS).start();
    }

    private void pop(TextView tv) {
        tv.animate().cancel();
        tv.setAlpha(0f);
        tv.setScaleX(0.85f);
        tv.setScaleY(0.85f);
        tv.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(FADE_MS).start();
    }

    private void typewriter(final TextView tv, final CharSequence original) {
        final String full = original.toString();
        typing.put(tv, Boolean.TRUE);
        tv.post(new Runnable() {
            private int shown = 0;
            private String last = null;

            @Override
            public void run() {
                try {
                    if (last != null && !last.equals(tv.getText().toString())) {
                        typing.remove(tv); // someone else changed the text: stop
                        return;
                    }
                    if (!enabled || !tv.isAttachedToWindow() || shown >= full.length()) {
                        tv.setText(original); // restore spans / styling
                        seen.put(tv, snapshot(original));
                        typing.remove(tv);
                        return;
                    }
                    shown++;
                    last = full.substring(0, shown);
                    tv.setText(last);
                    tv.postDelayed(this, TYPEWRITER_STEP_MS);
                } catch (Throwable t) {
                    typing.remove(tv);
                    fail(t);
                }
            }
        });
    }

    // ----------------------------------------------------------------- helpers

    private int readStyle() {
        try {
            int s = margyt().prefs().getInt("style", STYLE_FADE_SLIDE);
            return (s >= STYLE_FADE_SLIDE && s <= STYLE_POP) ? s : STYLE_FADE_SLIDE;
        } catch (Throwable t) {
            return STYLE_FADE_SLIDE;
        }
    }

    /** Never let an error reach TikTok; after a few errors the plugin switches itself off. */
    void fail(Throwable t) {
        errors++;
        if (errors <= MAX_ERRORS) {
            try { margyt().log("TextAnimation error #" + errors + ": " + t); } catch (Throwable ignored) {}
        }
        if (errors >= MAX_ERRORS) enabled = false;
    }

    boolean isEnabled() { return enabled; }

    // ------------------------------------------------------------ root listener

    private static final class RootListener implements ViewTreeObserver.OnPreDrawListener {
        private final TextAnimation plugin;
        private final WeakReference<View> ref;
        private long lastScan;
        private boolean pending;
        private final Runnable delayedScan = new Runnable() {
            @Override public void run() {
                pending = false;
                RootListener.this.scanNow();
            }
        };

        RootListener(TextAnimation plugin, View root) {
            this.plugin = plugin;
            this.ref = new WeakReference<View>(root);
        }

        @Override
        public boolean onPreDraw() {
            try {
                if (!plugin.isEnabled()) return true;
                View root = ref.get();
                if (root == null) return true;
                long now = SystemClock.uptimeMillis();
                if (now - lastScan >= SCAN_INTERVAL_MS) {
                    scanNow();
                } else if (!pending) {
                    // Don't miss a change that happens between two scans.
                    pending = true;
                    root.postDelayed(delayedScan, SCAN_INTERVAL_MS);
                }
            } catch (Throwable t) {
                plugin.fail(t);
            }
            return true; // never block drawing
        }

        void scanNow() {
            try {
                View root = ref.get();
                if (root == null || !plugin.isEnabled()) return;
                lastScan = SystemClock.uptimeMillis();
                plugin.scan(root);
            } catch (Throwable t) {
                plugin.fail(t);
            }
        }
    }
}
