package p3lixo.textanimation;

import android.app.Activity;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.SharedPreferences;
import android.os.SystemClock;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.ViewTreeObserver;
import android.view.animation.Interpolator;
import android.widget.EditText;
import android.widget.TextView;
import cat.narezany.margyt.plugin.MargyPlugin;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Map;
import java.util.WeakHashMap;

/**
 * Text Animation.
 *
 *  - typing in input fields: per-letter animation, particles on delete, combo, reactions (Fx);
 *  - other text: a light fade/slide when a TextView's text changes;
 *  - settings: tap (or long-press) the plugin's row in the mod's plugin list.
 *
 * The plugin never attaches listeners to non-input TextViews; it only polls the view tree.
 * Errors never reach TikTok: after a few of them the plugin switches itself off.
 */
public final class TextAnimation extends MargyPlugin {

    private static final String NAME_EN = "Text Animation";
    private static final String NAME_RU = "Анимация текста";

    private static final long SCAN_INTERVAL_MS = 200;
    private static final int MAX_ANIMATIONS_PER_SCAN = 8;
    private static final int MAX_DEPTH = 60;
    private static final int MAX_SNAPSHOT_CHARS = 200;
    private static final int MAX_ERRORS = 10;

    final Cfg cfg = new Cfg();

    private final Map<TextView, String> seen = new WeakHashMap<TextView, String>();
    private final Map<EditText, Fx> fxs = new WeakHashMap<EditText, Fx>();
    private final Map<View, Boolean> rows = new WeakHashMap<View, Boolean>();
    private final Map<View, RootListener> roots = new WeakHashMap<View, RootListener>();

    private boolean enabled;
    private int errors;
    private int budget;

    // ---------------------------------------------------------------- lifecycle

    @Override
    public void onStart(Context context) {
        enabled = true;
        try {
            cfg.load(margyt().prefs());
        } catch (Throwable t) {
            fail(t);
        }
        margyt().log("TextAnimation: started");
    }

    @Override
    public void onActivityResumed(Activity activity) {
        if (!enabled) return;
        try {
            View decor = activity.getWindow().getDecorView();
            if (!roots.containsKey(decor)) {
                ViewTreeObserver vto = decor.getViewTreeObserver();
                if (vto != null && vto.isAlive()) {
                    RootListener l = new RootListener(this, decor);
                    vto.addOnPreDrawListener(l);
                    roots.put(decor, l);
                }
            }
            scan(decor);
        } catch (Throwable t) {
            fail(t);
        }
    }

    @Override
    public void onStop() {
        enabled = false;
        try {
            for (View v : new ArrayList<View>(roots.keySet())) {
                RootListener l = roots.get(v);
                if (v != null && l != null) {
                    ViewTreeObserver vto = v.getViewTreeObserver();
                    if (vto != null && vto.isAlive()) vto.removeOnPreDrawListener(l);
                }
            }
            releaseAllFx();
            Overlay.releaseAll();
            for (TextView tv : new ArrayList<TextView>(seen.keySet())) {
                if (tv == null) continue;
                tv.animate().cancel();
                tv.setAlpha(1f);
                tv.setTranslationY(0f);
            }
        } catch (Throwable t) {
            // ignore on shutdown
        }
        roots.clear();
        seen.clear();
        margyt().log("TextAnimation: stopped");
    }

    // ------------------------------------------------------------ used by the UI

    SharedPreferences prefs() {
        return margyt().prefs();
    }

    /** Typing effects for a field that scan() would not find (the settings preview). */
    Fx attachFx(EditText tv) {
        Fx fx = fxs.get(tv);
        if (fx != null) return fx;
        if (Fx.secure(tv)) return null;
        fx = new Fx(this, cfg, tv);
        fx.attach(tv);
        fxs.put(tv, fx);
        return fx;
    }

    void detachFx(EditText tv) {
        Fx fx = fxs.remove(tv);
        if (fx != null) fx.release();
    }

    /** Called after any setting changed. */
    void onCfgChanged() {
        try {
            if (!cfg.on(Cfg.TYPING)) {
                releaseAllFx();
                return;
            }
            for (Fx fx : new ArrayList<Fx>(fxs.values())) fx.onCfgChanged();
        } catch (Throwable t) {
            fail(t);
        }
    }

    private void releaseAllFx() {
        for (Fx fx : new ArrayList<Fx>(fxs.values())) fx.release();
        fxs.clear();
    }

    // ---------------------------------------------------------------- scanning

    void scan(View root) {
        budget = MAX_ANIMATIONS_PER_SCAN;
        visit(root, 0);
    }

    private void visit(View v, int depth) {
        if (v == null || depth > MAX_DEPTH || v.getVisibility() != View.VISIBLE) return;
        if (v instanceof EditText) {
            if (cfg.on(Cfg.TYPING)) attachFx((EditText) v);
        } else if (v instanceof TextView) {
            TextView tv = (TextView) v;
            checkRow(tv);
            if (cfg.on(Cfg.OTHER)) check(tv);
        }
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0, n = g.getChildCount(); i < n; i++) {
                visit(g.getChildAt(i), depth + 1);
            }
        }
    }

    private static String snapshot(CharSequence t) {
        if (t == null) return "";
        int len = t.length();
        if (len > MAX_SNAPSHOT_CHARS) return "\u0000" + len;
        return t.toString();
    }

    private void check(TextView tv) {
        CharSequence text = tv.getText();
        String key = snapshot(text);
        String prev = seen.get(tv);
        if (prev == null) {
            seen.put(tv, key);
            return;
        }
        if (prev.equals(key)) return;
        seen.put(tv, key);
        if (key.length() == 0 || budget <= 0 || !tv.isShown()) return;
        budget--;
        fadeSlide(tv);
    }

    private void fadeSlide(TextView tv) {
        final int mode = cfg.get(Cfg.EASING);
        float dy = cfg.on(Cfg.SLIDE)
                ? Math.min(cfg.get(Cfg.SLIDE_DIST), 12) * tv.getResources().getDisplayMetrics().density
                : 0f;
        tv.animate().cancel();
        tv.setAlpha(0f);
        tv.setTranslationY(dy);
        tv.animate().alpha(1f).translationY(0f)
                .setDuration(cfg.get(Cfg.DURATION))
                .setInterpolator(new Interpolator() {
                    @Override public float getInterpolation(float t) {
                        return Ease.apply(mode, t);
                    }
                }).start();
    }

    // --------------------------------------------------- settings entry in the mod

    /** Finds our row in the mod's plugin list and makes it open the settings. */
    private void checkRow(TextView tv) {
        CharSequence t = tv.getText();
        if (t == null) return;
        int n = t.length();
        if (n != NAME_EN.length() && n != NAME_RU.length()) return;
        String s = t.toString();
        if (!s.equalsIgnoreCase(NAME_EN) && !s.equalsIgnoreCase(NAME_RU)) return;
        if (rows.containsKey(tv)) return;
        rows.put(tv, Boolean.TRUE);

        View row = findRow(tv);
        final View.OnClickListener open = new View.OnClickListener() {
            @Override public void onClick(View v) {
                try {
                    Activity a = activityOf(v.getContext());
                    if (a != null) SettingsUi.show(a, TextAnimation.this);
                } catch (Throwable e) {
                    fail(e);
                }
            }
        };
        // never replace a handler the mod already installed
        if (!row.isClickable()) {
            row.setOnClickListener(open);
        } else if (!row.isLongClickable()) {
            row.setOnLongClickListener(new View.OnLongClickListener() {
                @Override public boolean onLongClick(View v) {
                    open.onClick(v);
                    return true;
                }
            });
        }
        vlog("settings row attached");
    }

    private static View findRow(TextView tv) {
        View v = tv;
        for (int i = 0; i < 4; i++) {
            if (v.isClickable()) return v;
            ViewParent p = v.getParent();
            if (!(p instanceof View)) break;
            v = (View) p;
        }
        ViewParent p = tv.getParent();
        return p instanceof View ? (View) p : tv;
    }

    private static Activity activityOf(Context c) {
        while (c instanceof ContextWrapper) {
            if (c instanceof Activity) return (Activity) c;
            c = ((ContextWrapper) c).getBaseContext();
        }
        return null;
    }

    // ----------------------------------------------------------------- helpers

    boolean isEnabled() {
        return enabled;
    }

    void vlog(String s) {
        if (!cfg.on(Cfg.VERBOSE)) return;
        try {
            margyt().log("TextAnimation: " + s);
        } catch (Throwable ignored) {
        }
    }

    /** Never let an error reach TikTok; after a few errors the plugin switches itself off. */
    void fail(Throwable t) {
        errors++;
        if (errors <= MAX_ERRORS) {
            try {
                margyt().log("TextAnimation error #" + errors + ": " + t);
            } catch (Throwable ignored) {
            }
        }
        if (errors >= MAX_ERRORS && enabled) {
            enabled = false;
            try {
                releaseAllFx();
                Overlay.releaseAll();
            } catch (Throwable ignored) {
            }
        }
    }

    // ------------------------------------------------------------ root listener

    private static final class RootListener implements ViewTreeObserver.OnPreDrawListener {
        private final TextAnimation plugin;
        private final WeakReference<View> ref;
        private long lastScan;
        private boolean pending;
        private final Runnable delayedScan = new Runnable() {
            @Override public void run() {
                pending = false;
                RootListener.this.scanNow();
            }
        };

        RootListener(TextAnimation plugin, View root) {
            this.plugin = plugin;
            this.ref = new WeakReference<View>(root);
        }

        @Override
        public boolean onPreDraw() {
            try {
                if (!plugin.isEnabled()) return true;
                View root = ref.get();
                if (root == null) return true;
                long now = SystemClock.uptimeMillis();
                if (now - lastScan >= SCAN_INTERVAL_MS) {
                    scanNow();
                } else if (!pending) {
                    pending = true;
                    root.postDelayed(delayedScan, SCAN_INTERVAL_MS);
                }
            } catch (Throwable t) {
                plugin.fail(t);
            }
            return true; // never block drawing
        }

        void scanNow() {
            try {
                View root = ref.get();
                if (root == null || !plugin.isEnabled()) return;
                lastScan = SystemClock.uptimeMillis();
                plugin.scan(root);
            } catch (Throwable t) {
                plugin.fail(t);
            }
        }
    }
}
