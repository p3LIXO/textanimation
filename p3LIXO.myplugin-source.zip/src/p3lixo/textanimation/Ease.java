package p3lixo.textanimation;

import android.graphics.Color;

/** Small math helpers. */
final class Ease {
    private Ease() {}

    static float clamp01(float t) {
        return t < 0f ? 0f : (t > 1f ? 1f : t);
    }

    static float lerp(float a, float b, float t) {
        return a + (b - a) * t;
    }

    /** mode: 0 soft, 1 linear, 2 sharp, 3 spring (may overshoot 1). */
    static float apply(int mode, float t) {
        t = clamp01(t);
        switch (mode) {
            case 1:
                return t;
            case 2: {
                float u = 1f - t;
                return 1f - u * u * u * u * u;
            }
            case 3: {
                float c1 = 2.2f, c3 = c1 + 1f;
                float u = t - 1f;
                return 1f + c3 * u * u * u + c1 * u * u;
            }
            default: {
                float u = 1f - t;
                return 1f - u * u * u;
            }
        }
    }

    static int lerpColor(int a, int b, float t) {
        t = clamp01(t);
        int aa = (int) lerp(Color.alpha(a), Color.alpha(b), t);
        int r = (int) lerp(Color.red(a), Color.red(b), t);
        int g = (int) lerp(Color.green(a), Color.green(b), t);
        int bl = (int) lerp(Color.blue(a), Color.blue(b), t);
        return Color.argb(aa, r, g, bl);
    }
}
