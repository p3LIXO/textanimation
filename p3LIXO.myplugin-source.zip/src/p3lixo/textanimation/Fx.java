package p3lixo.textanimation;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.SystemClock;
import android.text.Editable;
import android.text.InputType;
import android.text.Layout;
import android.text.Spanned;
import android.text.TextWatcher;
import android.text.method.PasswordTransformationMethod;
import android.view.HapticFeedbackConstants;
import android.widget.EditText;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Random;

/**
 * Typing effects for ONE EditText.
 *
 * What it does on every edit:
 *  1. diffs old/new text, so an IME that re-sets the whole composing word only animates the
 *     truly new letters;
 *  2. hides each new real glyph with a GlyphSpan (colour only, no layout change) and draws an
 *     animated "ghost" of it on the window overlay (fade / slide / scale / tilt / blur / highlight);
 *  3. turns deleted letters into fading ghosts and particles;
 *  4. combo, reactions, haptics, cursor styling.
 *
 * Password fields are never touched. Typed text is never logged.
 */
final class Fx implements TextWatcher, Overlay.ComboSource {

    private static final int MAX_TRACK = 80;     // longest removed chunk we remember
    private static final int MAX_GLYPHS = 40;    // longest inserted chunk we animate
    private static final int MAX_ACTIVE = 60;
    private static final int MAX_WAVE_MS = 600;
    private static final int FLAGS = Spanned.SPAN_EXCLUSIVE_EXCLUSIVE;

    private final TextAnimation host;
    private final Cfg cfg;
    private final WeakReference<EditText> tvRef;
    private final ArrayList<Glyph> glyphs = new ArrayList<Glyph>();
    private final Random rnd = new Random();
    private final float[] tmp = new float[2];
    private final float[] org = new float[2];

    // pending edit (filled in beforeTextChanged / onTextChanged)
    private boolean pValid;
    private int pStart, pCount, pAfter;
    private char[] pOld;
    private float[] pX, pBase, pW;

    // combo
    private int combo;
    private long lastType;
    private boolean counterOn;
    private Overlay.Shake shake;
    private long shakeUntil;

    // cursor
    private Drawable origCursor;
    private boolean cursorApplied;

    Fx(TextAnimation host, Cfg cfg, EditText tv) {
        this.host = host;
        this.cfg = cfg;
        this.tvRef = new WeakReference<EditText>(tv);
    }

    // ---------------------------------------------------------------- lifecycle

    void attach(EditText tv) {
        tv.addTextChangedListener(this);
        applyCursor(tv);
    }

    void release() {
        EditText tv = tvRef.get();
        Editable e = tv != null ? tv.getText() : null;
        for (Glyph g : new ArrayList<Glyph>(glyphs)) g.finish(e);
        glyphs.clear();
        if (tv != null) {
            tv.removeTextChangedListener(this);
            restoreCursor(tv);
            if (shake != null) shake.restoreNow();
            tv.invalidate();
        }
    }

    void onCfgChanged() {
        EditText tv = tvRef.get();
        if (tv != null) applyCursor(tv);
    }

    // ------------------------------------------------------------- TextWatcher

    @Override
    public void beforeTextChanged(CharSequence s, int start, int count, int after) {
        pValid = false;
        pOld = null;
        pX = null;
        try {
            EditText tv = tvRef.get();
            if (tv == null) return;
            pStart = start;
            pCount = count;
            pAfter = after;
            if (count > 0 && count <= MAX_TRACK) {
                pOld = new char[count];
                for (int i = 0; i < count; i++) pOld[i] = s.charAt(start + i);
                if (wantDeleteFx() && cfg.on(Cfg.TYPING) && tv.hasFocus() && !secure(tv)) {
                    capturePositions(tv, start, count);
                }
            }
            pValid = true;
        } catch (Throwable t) {
            host.fail(t);
        }
    }

    @Override
    public void onTextChanged(CharSequence s, int start, int before, int count) {
        pAfter = count;
    }

    @Override
    public void afterTextChanged(Editable e) {
        EditText tv = tvRef.get();
        if (tv == null || !pValid) return;
        pValid = false;
        try {
            handle(tv, e);
        } catch (Throwable t) {
            host.fail(t);
        }
    }

    private boolean wantDeleteFx() {
        return cfg.on(Cfg.FADE_DEL) || cfg.on(Cfg.CRUMBLE);
    }

    private void capturePositions(EditText tv, int start, int count) {
        Layout l = tv.getLayout();
        if (l == null) return;
        Paint p = tv.getPaint();
        pX = new float[count];
        pBase = new float[count];
        pW = new float[count];
        for (int i = 0; i < count; i++) {
            if (!pos(tv, l, start + i, tmp)) {
                pX = null;
                return;
            }
            pW[i] = p.measureText(pOld, i, 1);
            pX[i] = tmp[0];
            pBase[i] = tmp[1];
        }
    }

    // ---------------------------------------------------------------- the edit

    private void handle(EditText tv, Editable e) {
        int start = pStart, rem = pCount, add = pAfter;
        if (start < 0 || start + add > e.length()) {
            for (Glyph g : new ArrayList<Glyph>(glyphs)) g.finish(e);
            glyphs.clear();
            return;
        }

        // common prefix / suffix: only the middle part really changed
        int cp = 0, cs = 0;
        if (pOld != null && rem > 0 && add > 0) {
            int max = Math.min(rem, add);
            while (cp < max && pOld[cp] == e.charAt(start + cp)) cp++;
            while (cs < max - cp && pOld[rem - 1 - cs] == e.charAt(start + add - 1 - cs)) cs++;
        }

        adjust(e, start, rem, add, cp, cs);

        if (!cfg.on(Cfg.TYPING) || !tv.hasFocus() || !tv.isShown() || secure(tv)) return;
        Overlay ov = Overlay.of(tv);
        if (ov == null) return;
        long now = SystemClock.uptimeMillis();
        float d = tv.getResources().getDisplayMetrics().density;

        // deletion: ghosts + particles
        int remCore = rem - cp - cs;
        if (remCore > 0 && pOld != null && pX != null && wantDeleteFx()) {
            deleteFx(tv, ov, cp, remCore, d);
        }

        // insertion: animated glyphs
        int addCore = add - cp - cs;
        boolean typed = addCore > 0 && addCore <= MAX_GLYPHS;
        if (typed) {
            spawnTyping(tv, e, ov, start + cp, addCore, now);
            afterTyping(tv, e, ov, start + cp, addCore, now, d);
        }
        host.vlog("edit +" + addCore + " -" + remCore + " active=" + glyphs.size());
    }

    /** Keeps hidden glyphs glued to the right character after any edit. */
    private void adjust(Editable e, int start, int rem, int add, int cp, int cs) {
        for (int i = glyphs.size() - 1; i >= 0; i--) {
            Glyph g = glyphs.get(i);
            if (g.dead) {
                glyphs.remove(i);
                continue;
            }
            if (g.off < start + cp) continue;
            if (g.off >= start + rem - cs) {
                g.off += add - rem;
            } else {
                g.finish(e);
                glyphs.remove(i);
            }
        }
        for (int i = glyphs.size() - 1; i >= 0; i--) {
            Glyph g = glyphs.get(i);
            if (g.off < 0 || g.off >= e.length()) {
                g.finish(e);
                glyphs.remove(i);
            } else if (e.getSpanStart(g.span) != g.off || e.getSpanEnd(g.span) != g.off + 1) {
                e.setSpan(g.span, g.off, g.off + 1, FLAGS);
            }
        }
    }

    private void spawnTyping(EditText tv, Editable e, Overlay ov, int firstOff, int n, long now) {
        int step = cfg.get(Cfg.WAVE_STEP);
        if (n > 1) step = Math.min(step, MAX_WAVE_MS / n);
        boolean wave = cfg.on(Cfg.PER_CHAR) && cfg.on(Cfg.WAVE);
        for (int k = 0; k < n; k++) {
            if (glyphs.size() >= MAX_ACTIVE) break;
            int off = firstOff + k;
            char ch = e.charAt(off);
            if (skipChar(ch)) continue;
            Glyph g = new Glyph(tv, ov, ch, off, now + (wave ? (long) k * step : 0L));
            glyphs.add(g);
            e.setSpan(g.span, off, off + 1, FLAGS);
            ov.add(g);
        }
        tv.invalidate();
    }

    private boolean skipChar(char ch) {
        if (Character.isSurrogate(ch) || ch == '\n' || ch == '\r' || ch == '\t'
                || ch == '￼' || Character.isISOControl(ch)) return true;
        if (cfg.on(Cfg.IGN_SPACES) && Character.isWhitespace(ch)) return true;
        if (ch >= 0x0590 && ch <= 0x1CFF) return true; // joined / complex scripts: leave alone
        int t = Character.getType(ch);
        return t == Character.NON_SPACING_MARK || t == Character.ENCLOSING_MARK
                || t == Character.COMBINING_SPACING_MARK || t == Character.FORMAT;
    }

    // --------------------------------------------------------- combo / reactions

    private void afterTyping(EditText tv, Editable e, Overlay ov, int firstOff, int n,
                             long now, float d) {
        if (cfg.on(Cfg.HAPTIC)) {
            try {
                tv.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP);
            } catch (Throwable ignored) {
            }
        }
        float shakeDp = cfg.get(Cfg.SHAKE);

        if (cfg.on(Cfg.COMBO)) {
            combo = (now - lastType <= cfg.get(Cfg.COMBO_WIN)) ? combo + n : n;
            lastType = now;
            if (combo >= 5 && shakeDp > 0f) {
                shake(tv, ov, shakeDp * d * Math.min(1f, 0.3f + combo / 20f), now);
            }
            if (cfg.on(Cfg.SPARKS) && combo >= 8) {
                burst(tv, ov, cfg.accent(), 3, 1f, 2);
            }
            if (cfg.on(Cfg.COUNTER) && combo >= 5 && !counterOn) {
                counterOn = true;
                ov.add(new Overlay.Counter(tv, ov, this));
            }
        } else {
            combo = 0;
        }

        if (cfg.on(Cfg.REACT)) {
            boolean bang = false, ask = false;
            for (int k = 0; k < n; k++) {
                char ch = e.charAt(firstOff + k);
                if (ch == '!') bang = true;
                else if (ch == '?') ask = true;
            }
            if (bang) {
                burst(tv, ov, 0xFFFF5252, 10, 1.4f, 3);
                shake(tv, ov, Math.max(2f, shakeDp) * d * 1.4f, now);
            } else if (ask) {
                burst(tv, ov, 0xFFFFD54F, 8, 1.1f, 0);
                shake(tv, ov, Math.max(1.5f, shakeDp * 0.6f) * d, now);
            }
        }
    }

    private void shake(EditText tv, Overlay ov, float amp, long now) {
        if (shake != null && now < shakeUntil) {
            shake.refresh(amp);
        } else {
            shake = new Overlay.Shake(tv, amp, 240);
            ov.add(shake);
        }
        shakeUntil = now + 240;
    }

    /** Particles at the caret. */
    private void burst(EditText tv, Overlay ov, int color, int count, float power, int shape) {
        Layout l = tv.getLayout();
        if (l == null || !pos(tv, l, tv.getSelectionEnd(), tmp)) return;
        ov.origin(tv, org);
        float d = tv.getResources().getDisplayMetrics().density;
        float x = org[0] + tmp[0];
        float y = org[1] + tmp[1] - tv.getTextSize() * 0.35f;
        for (int k = 0; k < count; k++) {
            double ang = -Math.PI / 2 + (rnd.nextFloat() * 2f - 1f) * 1.3f;
            float sp = d * (90f + rnd.nextFloat() * 150f) * power;
            ov.particles.add(x, y, (float) Math.cos(ang) * sp, (float) Math.sin(ang) * sp,
                    d * (2f + rnd.nextFloat() * 2.5f), 0.35f + rnd.nextFloat() * 0.35f,
                    color, shape == 3 ? rnd.nextInt(3) : shape, d * 520f);
        }
        ov.wake();
    }

    // ------------------------------------------------------------ deletion fx

    private void deleteFx(EditText tv, Overlay ov, int cp, int remCore, float d) {
        ov.origin(tv, org);
        int color = tv.getCurrentTextColor();
        Paint pc = new Paint(tv.getPaint());
        pc.clearShadowLayer();
        float ts = pc.getTextSize();

        int nPcs = cfg.get(Cfg.PCS);
        float speed = d * (30f + 4f * cfg.get(Cfg.FLY_SPEED));
        float half = (float) Math.toRadians(15f + 1.65f * cfg.get(Cfg.SPREAD));
        float grav = cfg.on(Cfg.GRAVITY) ? d * 900f * cfg.get(Cfg.GRAV_STR) / 100f : 0f;
        float size = d * 2.4f * cfg.get(Cfg.PSIZE) / 50f;
        int shape = cfg.get(Cfg.SHAPE);

        int made = 0;
        for (int i = cp; i < cp + remCore && made < MAX_GLYPHS; i++) {
            char ch = pOld[i];
            if (Character.isWhitespace(ch) || Character.isISOControl(ch)
                    || Character.isSurrogate(ch) || ch == '￼') continue;
            made++;
            float x = org[0] + pX[i];
            float base = org[1] + pBase[i];
            if (cfg.on(Cfg.FADE_DEL)) {
                ov.add(new Overlay.Ghost(ch, pc, color, x, base, 8f * d, 260f));
            }
            if (cfg.on(Cfg.CRUMBLE)) {
                for (int k = 0; k < nPcs; k++) {
                    float px = x + rnd.nextFloat() * pW[i];
                    float py = base - rnd.nextFloat() * ts * 0.7f;
                    double ang = -Math.PI / 2 + (rnd.nextFloat() * 2f - 1f) * half;
                    float sp = speed * (0.4f + 0.8f * rnd.nextFloat());
                    ov.particles.add(px, py, (float) Math.cos(ang) * sp, (float) Math.sin(ang) * sp,
                            size * (0.5f + rnd.nextFloat() * 0.9f), 0.45f + rnd.nextFloat() * 0.45f,
                            color, shape == 3 ? rnd.nextInt(3) : shape, grav);
                }
            }
        }
        ov.wake();
    }

    // ------------------------------------------------------------------ cursor

    private void applyCursor(EditText tv) {
        if (Build.VERSION.SDK_INT < 29) return;
        try {
            if (cfg.on(Cfg.CURSOR) && cfg.on(Cfg.TYPING)) {
                if (!cursorApplied) {
                    origCursor = tv.getTextCursorDrawable();
                    if (origCursor == null) return;
                    cursorApplied = true;
                }
                float d = tv.getResources().getDisplayMetrics().density;
                GradientDrawable g = new GradientDrawable();
                g.setColor(cfg.accent());
                g.setSize(Math.max(1, Math.round(cfg.get(Cfg.CURSOR_W) * d)), -1);
                tv.setTextCursorDrawable(g);
            } else {
                restoreCursor(tv);
            }
        } catch (Throwable t) {
            host.fail(t);
        }
    }

    private void restoreCursor(EditText tv) {
        if (Build.VERSION.SDK_INT < 29 || !cursorApplied) return;
        try {
            tv.setTextCursorDrawable(origCursor);
        } catch (Throwable ignored) {
        }
        cursorApplied = false;
    }

    // ----------------------------------------------------------------- helpers

    /** left edge and baseline of the character at off, in the view's own coordinates. */
    static boolean pos(EditText tv, Layout l, int off, float[] out) {
        if (off < 0 || off > tv.length()) return false;
        int line = l.getLineForOffset(off);
        out[0] = tv.getCompoundPaddingLeft() - tv.getScrollX() + l.getPrimaryHorizontal(off);
        out[1] = tv.getBaseline() - l.getLineBaseline(0) + l.getLineBaseline(line) - tv.getScrollY();
        return true;
    }

    static boolean secure(EditText tv) {
        if (tv.getTransformationMethod() instanceof PasswordTransformationMethod) return true;
        int it = tv.getInputType();
        int cls = it & InputType.TYPE_MASK_CLASS;
        int var = it & InputType.TYPE_MASK_VARIATION;
        if (cls == InputType.TYPE_CLASS_TEXT) {
            return var == InputType.TYPE_TEXT_VARIATION_PASSWORD
                    || var == InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD
                    || var == InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD;
        }
        if (cls == InputType.TYPE_CLASS_NUMBER) {
            return var == InputType.TYPE_NUMBER_VARIATION_PASSWORD;
        }
        return false;
    }

    // --------------------------------------------------------- ComboSource

    @Override public int combo() { return combo; }
    @Override public long lastType() { return lastType; }
    @Override public int windowMs() { return cfg.get(Cfg.COMBO_WIN); }
    @Override public int accent() { return cfg.accent(); }
    @Override public void counterDone() { counterOn = false; combo = 0; }

    // ------------------------------------------------------------------ glyph

    /** One animated ghost letter. The real glyph stays hidden (GlyphSpan) until it ends. */
    private final class Glyph implements Overlay.Item {
        final WeakReference<EditText> ref;
        final Overlay ov;
        final char[] ch = new char[1];
        final GlyphSpan span = new GlyphSpan();
        final Paint paint;
        final float w, density;
        final int baseColor;
        final long t0;
        final float[] p = new float[2], o = new float[2];
        int off;
        boolean dead;

        Glyph(EditText tv, Overlay ov, char c, int off, long t0) {
            this.ref = new WeakReference<EditText>(tv);
            this.ov = ov;
            this.ch[0] = c;
            this.off = off;
            this.t0 = t0;
            this.paint = new Paint(tv.getPaint());
            this.paint.clearShadowLayer();
            this.paint.setStyle(Paint.Style.FILL);
            this.w = paint.measureText(ch, 0, 1);
            this.baseColor = tv.getCurrentTextColor();
            this.density = tv.getResources().getDisplayMetrics().density;
        }

        void finish(Editable e) {
            if (dead) return;
            dead = true;
            try {
                if (e != null) e.removeSpan(span);
            } catch (Throwable ignored) {
            }
        }

        private long totalMs() {
            long t = cfg.get(Cfg.DURATION);
            if (cfg.on(Cfg.BLUR)) t = Math.max(t, cfg.get(Cfg.BLUR_DUR));
            return t;
        }

        @Override
        public boolean step(long now, float dt) {
            if (dead) return false;
            EditText tv = ref.get();
            if (tv == null) {
                dead = true;
                return false;
            }
            if (now - t0 >= totalMs()) {
                finish(tv.getText());
                glyphs.remove(this);
                tv.invalidate();
                return false;
            }
            return true;
        }

        @Override
        public void draw(Canvas c, long now) {
            if (dead) return;
            long el = now - t0;
            if (el < 0) return;
            EditText tv = ref.get();
            if (tv == null || !tv.isShown()) return;
            Layout l = tv.getLayout();
            if (l == null || off < 0 || off >= tv.length() || !pos(tv, l, off, p)) return;
            if (p[0] + w < 0 || p[0] > tv.getWidth()) return;
            ov.origin(tv, o);
            float x = o[0] + p[0];
            float y = o[1] + p[1];

            float d = density;
            float dur = Math.max(1, cfg.get(Cfg.DURATION));
            float e = Ease.apply(cfg.get(Cfg.EASING), el / dur);
            float fade = Ease.clamp01(e);

            boolean blurOn = cfg.on(Cfg.BLUR);
            float sharp = 1f;
            if (blurOn) {
                float bt = Ease.clamp01(el / (float) Math.max(1, cfg.get(Cfg.BLUR_DUR)));
                float pf = cfg.get(Cfg.BLUR_PAUSE) / 100f;
                sharp = Ease.apply(0, Ease.clamp01((bt - pf) / Math.max(0.05f, 1f - pf)));
            }

            float dy = cfg.on(Cfg.SLIDE) ? -cfg.get(Cfg.SLIDE_DIST) * d * (1f - e) : 0f;
            float sc = cfg.on(Cfg.SCALE) ? Ease.lerp(cfg.get(Cfg.SCALE_START) / 100f, 1f, e) : 1f;
            float rot = cfg.on(Cfg.ROTATE) ? cfg.get(Cfg.ANGLE) * (1f - e) : 0f;

            int col = baseColor;
            if (cfg.on(Cfg.HIGHLIGHT)) {
                col = Ease.lerpColor(col, cfg.accent(),
                        cfg.get(Cfg.HL_STRENGTH) / 100f * (1f - Ease.clamp01(e)));
            }

            float cx = x + w / 2f;
            float cy = y - paint.getTextSize() * 0.35f;
            int baseA = Color.alpha(col);

            c.save();
            if (rot != 0f) c.rotate(rot, cx, cy);
            if (sc != 1f) c.scale(sc, sc, cx, cy);

            if (blurOn && sharp < 1f) {
                float r = cfg.get(Cfg.BLUR_STRENGTH) * 0.4f * d * (1f - sharp);
                paint.setColor(col);
                paint.setAlpha((int) (baseA * fade * (1f - sharp) * 0.4f));
                for (int k = 0; k < 6; k++) {
                    double a = k * Math.PI / 3.0;
                    c.drawText(ch, 0, 1, x + (float) Math.cos(a) * r, y + dy + (float) Math.sin(a) * r,
                            paint);
                }
            }
            paint.setColor(col);
            paint.setAlpha((int) (baseA * fade * sharp));
            c.drawText(ch, 0, 1, x, y + dy, paint);
            c.restore();
        }
    }
}
