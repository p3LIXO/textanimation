package cat.narezany.margyt.plugin;

import android.app.Activity;
import android.content.Context;

/**
 * Stub for COMPILING plugins only. Never dex these classes:
 * the real ones are already inside the app.
 */
public class MargyPlugin {

    public static final int API = 1;

    protected final PluginContext margyt() {
        return null;
    }

    public void onStart(Context context) { }

    public void onActivityCreated(Activity activity) { }

    public void onActivityResumed(Activity activity) { }

    public void onActivityPaused(Activity activity) { }

    public int onColour(int colour) {
        return colour;
    }

    public String onRegion(String key, String value) {
        return value;
    }

    public void onStop() { }
}
