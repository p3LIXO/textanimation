package cat.narezany.margyt.plugin;
public abstract class MargyPlugin {
    protected final PluginContext margyt() { return null; }
    public void onStart(android.content.Context c) {}
    public void onActivityCreated(android.app.Activity a) {}
    public void onActivityResumed(android.app.Activity a) {}
    public void onActivityPaused(android.app.Activity a) {}
    public int onColour(int c) { return c; }
    public String onRegion(String key, String value) { return value; }
    public void onStop() {}
}
