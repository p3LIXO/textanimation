package cat.narezany.margyt.plugin;

import android.content.Context;
import android.content.SharedPreferences;
import java.io.File;

/**
 * Stub for COMPILING plugins only. Never dex these classes.
 */
public final class PluginContext {

    public Context context() {
        return null;
    }

    public String id() {
        return null;
    }

    public File folder() {
        return null;
    }

    public SharedPreferences prefs() {
        return null;
    }

    public void log(String line) { }
}
