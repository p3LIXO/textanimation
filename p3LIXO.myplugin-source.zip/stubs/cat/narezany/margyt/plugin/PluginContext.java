package cat.narezany.margyt.plugin;
public interface PluginContext {
    android.content.Context context();
    String id();
    java.io.File folder();
    android.content.SharedPreferences prefs();
    void log(String s);
}
