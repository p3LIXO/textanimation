#!/usr/bin/env bash
# Builds p3LIXO.myplugin.mtp
# Needs: JDK 8+, Android SDK (build-tools with d8 + platforms/android-XX/android.jar), zip.
#   export ANDROID_HOME=~/Android/Sdk
set -euo pipefail
cd "$(dirname "$0")"

: "${ANDROID_HOME:?set ANDROID_HOME to your Android SDK}"
D8=$(ls -d "$ANDROID_HOME"/build-tools/*/d8 | sort -V | tail -1)
ANDROID_JAR=$(ls -d "$ANDROID_HOME"/platforms/android-*/android.jar | sort -V | tail -1)

rm -rf out/classes out/stubs out/pkg && mkdir -p out/classes out/stubs out/pkg

# 1) MargyPlugin/PluginContext stubs: compile-time ONLY, never packed into the dex.
#    (Replace stubs/cat/... with the real MargyT API jar if you have it.)
javac --release 8 -d out/stubs $(find stubs/cat -name '*.java') -cp "$ANDROID_JAR"

# 2) Compile the plugin against android.jar + the API stubs.
javac --release 8 -cp "$ANDROID_JAR:out/stubs" -d out/classes $(find src -name '*.java')

# 3) Dex only the plugin classes.
"$D8" --min-api 21 --lib "$ANDROID_JAR" --output out/pkg $(find out/classes -name '*.class')

# 4) Pack: exactly manifest.json + classes.dex (+ icon.png), flat.
cp manifest.json icon.png out/pkg/
( cd out/pkg && rm -f ../../p3LIXO.myplugin.mtp && zip -X -q ../../p3LIXO.myplugin.mtp manifest.json classes.dex icon.png )
echo "Built: $(pwd)/p3LIXO.myplugin.mtp"
